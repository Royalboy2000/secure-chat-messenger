document.addEventListener('DOMContentLoaded', function() {
    let currentPeer = null;
    let users = [];
    let messages = {};
    let currentTab = 'chats';
    let token = localStorage.getItem('crypsis_token');
    let username = localStorage.getItem('crypsis_username') || 'User';

    // Redirect to login if not authenticated
    if (!token) {
        window.location.href = 'login.html';
        return;
    }

    const $ = (s) => document.querySelector(s);
    const $$ = (s) => document.querySelectorAll(s);

    // Empty users array - no example chats
    const mockUsers = [];

    function initializeApp() {
        setupEventListeners();
        setupThemeToggle();
        setupTabNavigation();
        setupFileUpload();
        loadUsers();
        
        // Show empty state since no users
        renderUserList();
    }

    function setupThemeToggle() {
        const themeToggle = $('#themeToggle');
        const currentTheme = localStorage.getItem('theme') || 'dark';
        
        if (currentTheme === 'light') {
            document.documentElement.setAttribute('data-theme', 'light');
        }
        
        themeToggle.addEventListener('click', function() {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            if (newTheme === 'light') {
                document.documentElement.setAttribute('data-theme', 'light');
            } else {
                document.documentElement.removeAttribute('data-theme');
            }
            
            localStorage.setItem('theme', newTheme);
        });
    }

    function setupTabNavigation() {
        const navTabs = $$('.nav-tab');
        const tabPanes = $$('.tab-pane');
        
        navTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                const targetTab = this.dataset.tab;
                
                // Update active tab
                navTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
                // Update active pane
                tabPanes.forEach(pane => pane.classList.remove('active'));
                $(`#${targetTab}Tab`).classList.add('active');
                
                currentTab = targetTab;
                
                // Update search placeholder
                const searchInput = $('#chatSearch');
                switch(targetTab) {
                    case 'chats':
                        searchInput.placeholder = 'Search chats...';
                        break;
                    case 'contacts':
                        searchInput.placeholder = 'Search contacts...';
                        break;
                    case 'calls':
                        searchInput.placeholder = 'Search calls...';
                        break;
                }
            });
        });
    }

    function setupFileUpload() {
        const fileBtn = $('#fileBtn');
        const fileInput = $('#fileInput');
        
        fileBtn.addEventListener('click', function() {
            fileInput.click();
        });
        
        fileInput.addEventListener('change', function(e) {
            const files = Array.from(e.target.files);
            if (files.length > 0 && currentPeer) {
                files.forEach(file => {
                    sendFileMessage(file);
                });
            }
            // Reset input
            e.target.value = '';
        });
    }

    function sendFileMessage(file) {
        if (!currentPeer) return;
        
        const fileMessage = {
            from: username,
            to: currentPeer,
            text: `📎 ${file.name} (${formatFileSize(file.size)})`,
            type: 'file',
            file: {
                name: file.name,
                size: file.size,
                type: file.type
            },
            timestamp: new Date().toISOString()
        };
        
        // Add to messages
        if (!messages[currentPeer]) {
            messages[currentPeer] = [];
        }
        messages[currentPeer].push(fileMessage);
        
        // Re-render messages and user list
        renderMessages();
        renderUserList();
        
        // Simulate response
        simulateResponse();
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function loadUsers() {
        // Start with empty users array - no example chats
        users = mockUsers.filter(u => u.username !== username);
        
        // Initialize empty messages
        users.forEach(user => {
            if (!messages[user.username]) {
                messages[user.username] = [];
            }
        });
        
        renderUserList();
    }

    function renderUserList() {
        const list = $('#convList');
        
        if (users.length === 0) {
            list.innerHTML = `
                <div class="empty-state">
                    <p>No chats yet</p>
                    <p style="font-size: 12px; opacity: 0.7;">Start a conversation by adding contacts</p>
                </div>
            `;
            return;
        }

        list.innerHTML = users.map(user => `
            <div class="conv-item" data-username="${user.username}">
                <div class="avatar ${getStatusClass(user.status)}">${user.username.substring(0, 2).toUpperCase()}</div>
                <div class="ci-main">
                    <div class="ci-name">${user.username}</div>
                    <div class="ci-snippet">${getLastMessagePreview(user.username)}</div>
                </div>
            </div>
        `).join('');

        // Add click event listeners to conversation items
        $$('.conv-item').forEach(item => {
            item.addEventListener('click', function(event) {
                const username = this.dataset.username;
                selectUser(username, event);
            });
        });
    }

    function getStatusClass(status) {
        switch(status) {
            case 'online': return '';
            case 'away': return 'away';
            case 'background': return 'background';
            case 'offline': return 'offline';
            default: return 'offline';
        }
    }

    function getLastMessagePreview(user) {
        const userMessages = messages[user] || [];
        if (userMessages.length === 0) return 'No messages yet';
        
        const lastMessage = userMessages[userMessages.length - 1];
        const preview = lastMessage.text.length > 30 ? 
            lastMessage.text.substring(0, 30) + '...' : 
            lastMessage.text;
        
        return lastMessage.from === username ? preview : `You: ${preview}`;
    }

    function selectUser(peer, event) {
        currentPeer = peer;
        
        // Update active state
        $$('.conv-item').forEach(item => item.classList.remove('active'));
        if (event && event.currentTarget) {
            event.currentTarget.classList.add('active');
        } else {
            // Find and activate the correct item
            const targetItem = $(`.conv-item[data-username="${peer}"]`);
            if (targetItem) {
                targetItem.classList.add('active');
            }
        }
        
        // Update header
        $('#peerName').textContent = peer;
        $('#peerAvatar').textContent = peer.substring(0, 2).toUpperCase();
        
        // Update status
        const user = users.find(u => u.username === peer);
        if (user) {
            const statusDot = $('#statusDot');
            const statusText = $('#statusText');
            statusDot.className = 'status-dot';
            
            switch(user.status) {
                case 'online':
                    statusText.textContent = 'Online';
                    statusDot.style.background = 'var(--online)';
                    break;
                case 'away':
                    statusText.textContent = 'Away';
                    statusDot.style.background = 'var(--away)';
                    break;
                case 'background':
                    statusText.textContent = 'Running in Background';
                    statusDot.style.background = 'var(--background)';
                    break;
                case 'offline':
                    statusText.textContent = 'Offline';
                    statusDot.style.background = 'var(--offline)';
                    break;
            }
        }
        
        // Load and render messages
        renderMessages();
    }

    function renderMessages() {
        const msgsEl = $('#msgs');
        msgsEl.innerHTML = '';
        
        const msgs = messages[currentPeer] || [];
        msgs.forEach(msg => {
            const isOut = msg.from === username;
            const time = new Date(msg.timestamp).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
            
            const msgEl = document.createElement('div');
            msgEl.className = `msg ${isOut ? 'out' : 'in'}`;
            msgEl.innerHTML = `
                <div class="bubble">${msg.text}</div>
                <div class="meta"><span>${time}</span><span>✓✓</span></div>
            `;
            msgsEl.appendChild(msgEl);
        });
        
        msgsEl.scrollTop = msgsEl.scrollHeight;
    }

    function sendMessage() {
        const input = $('#msgInput');
        const text = input.value.trim();
        
        if (!text || !currentPeer) return;
        
        input.value = '';
        
        // Create new message
        const newMessage = {
            from: username,
            to: currentPeer,
            text: text,
            timestamp: new Date().toISOString()
        };
        
        // Add to messages
        if (!messages[currentPeer]) {
            messages[currentPeer] = [];
        }
        messages[currentPeer].push(newMessage);
        
        // Re-render messages and user list
        renderMessages();
        renderUserList();
        
        // Simulate typing indicator and auto-response
        simulateResponse();
    }

    function simulateResponse() {
        if (!currentPeer) return;
        
        // Show typing indicator
        const typingIndicator = $('#typingIndicator');
        typingIndicator.style.display = 'block';
        typingIndicator.textContent = `${currentPeer} is typing...`;
        
        // Simulate response after delay
        setTimeout(() => {
            typingIndicator.style.display = 'none';
            
            const responses = [
                "That's interesting!",
                "I see what you mean.",
                "Thanks for sharing that.",
                "Good point!",
                "I agree with you.",
                "That makes sense.",
                "Tell me more about that.",
                "Sounds good to me!",
                "I hadn't thought of it that way.",
                "That's a great idea!"
            ];
            
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            
            const responseMessage = {
                from: currentPeer,
                to: username,
                text: randomResponse,
                timestamp: new Date().toISOString()
            };
            
            messages[currentPeer].push(responseMessage);
            renderMessages();
            renderUserList();
            
        }, 1000 + Math.random() * 2000); // Random delay between 1-3 seconds
    }

    function setupEventListeners() {
        const msgInput = $('#msgInput');
        const sendBtn = $('.send');
        
        // Send message on Enter key
        msgInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
        
        // Send button click
        sendBtn.addEventListener('click', sendMessage);
        
        // Search functionality
        const searchInput = $('#chatSearch');
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            if (currentTab === 'chats') {
                $$('.conv-item').forEach(item => {
                    const username = item.querySelector('.ci-name').textContent.toLowerCase();
                    if (username.includes(searchTerm)) {
                        item.style.display = 'grid';
                    } else {
                        item.style.display = 'none';
                    }
                });
            }
        });
    }

    // Global functions
    window.sendMessage = sendMessage;
    
    window.logout = function() {
        if (confirm('Are you sure you want to sign out?')) {
            localStorage.clear();
            window.location.href = 'login.html';
        }
    };

    // Initialize the app
    initializeApp();
});
