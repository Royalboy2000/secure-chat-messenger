document.addEventListener('DOMContentLoaded', function() {
    const codeBox = document.getElementById('codeBox');
    const genBtn = document.getElementById('genBtn');
    const copyBtn = document.getElementById('copyBtn');
    const downloadBtn = document.getElementById('downloadBtn');
    const continueBtn = document.getElementById('continueBtn');
    const seedSection = document.getElementById('seedSection');
    const seedGrid = document.getElementById('seedGrid');
    const form = document.getElementById('signupForm');
    const usernameInput = document.getElementById('username');
    
    let generatedCode = '';
    let generatedSeed = [];

    function showError(input, show, msg) {
        const errorMsg = input.parentNode.querySelector('.error-message');
        input.classList.toggle('error', show);
        if (msg) errorMsg.textContent = msg;
        errorMsg.style.display = show ? 'block' : 'none';
    }

    function generateCode(len = 64) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let out = '';
        const cryptoObj = window.crypto || window.msCrypto;
        if (cryptoObj && cryptoObj.getRandomValues) {
            const bytes = new Uint8Array(len);
            cryptoObj.getRandomValues(bytes);
            for (let i = 0; i < len; i++) out += chars[bytes[i] % chars.length];
        } else {
            for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
        }
        return out;
    }

    function randomFrom(list) { 
        return list[Math.floor(Math.random() * list.length)]; 
    }

    const WORDS = [
        'alpha', 'bravo', 'charlie', 'delta', 'echo', 'foxtrot', 'golf', 'hotel', 'india', 'juliet', 'kilo', 'lima', 'mike', 'november', 'oscar', 'papa', 'quebec', 'romeo', 'sierra', 'tango', 'uniform', 'victor', 'whiskey', 'xray', 'yankee', 'zulu',
        'apple', 'banana', 'cherry', 'date', 'elder', 'fig', 'grape', 'hazel', 'ivy', 'juniper', 'kiwi', 'lemon', 'mango', 'nectar', 'olive', 'peach', 'quince', 'rose', 'sage', 'thyme', 'umbra', 'violet', 'willow', 'xenia', 'yucca', 'zest'
    ];

    function generateSeedWords(n = 12) {
        const out = [];
        const used = new Set();
        while (out.length < n) {
            const w = randomFrom(WORDS);
            if (!used.has(w)) { 
                used.add(w); 
                out.push(w); 
            }
        }
        return out;
    }

    function showSeed(words) {
        seedGrid.innerHTML = words.map((w, i) => `<div class="seed-word">${i + 1}. ${w}</div>`).join('');
        seedSection.classList.remove('hidden');
    }

    function validateUsername(username) {
        return /^[A-Za-z0-9_.-]{3,32}$/.test(username);
    }

    genBtn.addEventListener('click', () => {
        const uname = (usernameInput.value || '').trim();
        
        // Clear any previous errors
        showError(usernameInput, false);
        
        if (!validateUsername(uname)) {
            showError(usernameInput, true, 'Username must be 3-32 characters (letters, digits, _, ., -)');
            usernameInput.focus();
            return;
        }

        // Generate recovery code and seed phrases
        const code = generateCode(64);
        generatedCode = code;
        codeBox.textContent = code;
        codeBox.dataset.code = code;
        
        const seed = generateSeedWords(12);
        generatedSeed = seed;
        showSeed(seed);
        
        try {
            // Store user data in localStorage
            localStorage.setItem('crypsis_username', uname);
            localStorage.setItem('crypsis_recovery_code', code);
            localStorage.setItem('crypsis_seed_phrase', JSON.stringify(seed));
            localStorage.setItem('crypsis_token', 'authenticated_' + Date.now());
        } catch (e) {
            console.error('Failed to store data in localStorage:', e);
        }

        // Enable buttons
        genBtn.disabled = true;
        genBtn.textContent = 'Code Generated';
        copyBtn.disabled = false;
        downloadBtn.disabled = false;
        continueBtn.style.display = 'inline-block';
    });

    copyBtn.addEventListener('click', async () => {
        const code = codeBox.dataset.code || '';
        if (!code) return;
        
        try {
            await navigator.clipboard.writeText(code);
            copyBtn.textContent = 'Copied!';
            setTimeout(() => copyBtn.textContent = 'Copy', 1500);
        } catch (e) {
            // Fallback for browsers that don't support clipboard API
            const textArea = document.createElement('textarea');
            textArea.value = code;
            document.body.appendChild(textArea);
            textArea.select();
            try {
                document.execCommand('copy');
                copyBtn.textContent = 'Copied!';
                setTimeout(() => copyBtn.textContent = 'Copy', 1500);
            } catch (err) {
                console.error('Failed to copy text:', err);
            }
            document.body.removeChild(textArea);
        }
    });

    // Clear errors on input
    usernameInput.addEventListener('input', function() {
        if (usernameInput.classList.contains('error')) {
            showError(usernameInput, false);
        }
    });

    // Download button functionality
    downloadBtn.addEventListener('click', function() {
        if (!generatedCode || generatedSeed.length === 0) return;
        
        const username = usernameInput.value.trim();
        const content = `Crypsis Account Information
=============================

Username: ${username}
Recovery Code: ${generatedCode}

12 Seed Phrases:
${generatedSeed.map((word, index) => `${index + 1}. ${word}`).join('\n')}

=============================
Keep this information safe and secure!
Generated on: ${new Date().toLocaleString()}`;

        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `crypsis-backup-${username}-${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        downloadBtn.textContent = 'Downloaded!';
        setTimeout(() => downloadBtn.textContent = 'Download TXT', 2000);
    });

    // Continue button functionality
    continueBtn.addEventListener('click', function() {
        window.location.href = 'messenger.html';
    });

    // Initially disable buttons
    copyBtn.disabled = true;
    downloadBtn.disabled = true;
});
