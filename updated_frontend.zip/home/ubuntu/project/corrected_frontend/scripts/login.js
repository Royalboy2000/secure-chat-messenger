document.addEventListener('DOMContentLoaded', function() {
    const codeInput = document.getElementById('recovery');
    const submitBtn = document.getElementById('submitBtn');
    const form = document.getElementById('loginForm');

    function showError(input, show, msg) {
        const errorMsg = input.parentNode.querySelector('.error-message');
        input.classList.toggle('error', show);
        if (msg) errorMsg.textContent = msg;
        errorMsg.style.display = show ? 'block' : 'none';
    }

    function isValidCode(s) { 
        return /^[A-Za-z0-9]{64}$/.test(s); 
    }

    async function handleLogin(event) {
        event.preventDefault();
        const code = (codeInput.value || '').trim();
        
        // Clear any previous errors
        showError(codeInput, false);
        
        if (!isValidCode(code)) {
            showError(codeInput, true, 'Code must be exactly 64 letters and digits');
            return false;
        }

        // Loading UI
        const btnText = document.querySelector('.btn-text');
        const loading = document.querySelector('.loading');
        btnText.style.display = 'none';
        loading.style.display = 'flex';
        submitBtn.disabled = true;

        // Simulate network delay
        await new Promise(r => setTimeout(r, 600));

        try {
            // Check if recovery code exists in localStorage (from signup)
            const stored = localStorage.getItem('crypsis_recovery_code');
            
            if (stored && stored === code) {
                // Store authentication token
                localStorage.setItem('crypsis_token', 'authenticated_' + Date.now());
                
                // Success animation
                form.classList.add('success');
                
                // Redirect to messenger
                setTimeout(() => { 
                    window.location.href = 'messenger.html'; 
                }, 400);
            } else {
                // For demo purposes, also accept a default recovery code
                const defaultCode = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789AB';
                
                if (code === defaultCode) {
                    localStorage.setItem('crypsis_token', 'authenticated_' + Date.now());
                    localStorage.setItem('crypsis_username', 'DemoUser');
                    form.classList.add('success');
                    setTimeout(() => { 
                        window.location.href = 'messenger.html'; 
                    }, 400);
                } else {
                    showError(codeInput, true, 'Invalid Recovery Code. Try the demo code or create a new account.');
                    resetButton();
                }
            }
        } catch (e) {
            showError(codeInput, true, 'Unexpected error occurred');
            resetButton();
        }
        
        return false;
    }

    function resetButton() {
        const btnText = document.querySelector('.btn-text');
        const loading = document.querySelector('.loading');
        btnText.style.display = 'inline';
        loading.style.display = 'none';
        submitBtn.disabled = false;
    }

    // Event listeners
    form.addEventListener('submit', handleLogin);

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
            handleLogin(e);
        }
    });

    // Clear errors on input
    codeInput.addEventListener('input', function() {
        if (codeInput.classList.contains('error')) {
            showError(codeInput, false);
        }
    });
});
